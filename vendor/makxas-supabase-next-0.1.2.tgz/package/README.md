# @makxas/supabase-next

Shared Supabase SSR helpers for Next.js apps in the makxas group.

Eliminates the `lib/supabase/{client,server,middleware}.ts` boilerplate that was
copy-pasted across 6 repos (portal / front / sell / search / data-portal /
accounting-ui). All consumers now standardize on the same env-var names and
cookie handling pattern.

## Install

Via GitHub Packages (requires `NPM_TOKEN` with `read:packages` for `MAKXAS` org):

```bash
# .npmrc
@makxas:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NPM_TOKEN}
```

```bash
npm install @makxas/supabase-next
```

## Env vars

Reads from these by default; override per-call via the `options` arg if needed:

| Var | Used by | Required |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | all | yes |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | browser / server / middleware | yes |
| `SUPABASE_SERVICE_ROLE_KEY` | service client only | only if used |

## Usage

### Browser (Client Components)

```ts
// lib/supabase/client.ts
import { createMakxasBrowserClient } from "@makxas/supabase-next";
import type { Database } from "../database.types";

export const createClient = () => createMakxasBrowserClient<Database>();
```

### Server (Server Components / Route Handlers / Server Actions)

```ts
// lib/supabase/server.ts
import {
  createMakxasServerClient,
  createMakxasServiceClient,
} from "@makxas/supabase-next";
import type { Database } from "../database.types";

export const createClient = () => createMakxasServerClient<Database>();
export const createServiceClient = () => createMakxasServiceClient<Database>();
```

### Middleware

Each repo's `middleware.ts` composes route protection logic itself (the public
paths and redirect rules are too repo-specific to share). This SDK only
provides the Supabase + cookie mechanics:

```ts
// middleware.ts (or lib/supabase/middleware.ts)
import { createMakxasMiddlewareClient } from "@makxas/supabase-next";
import { NextResponse, type NextRequest } from "next/server";

const PUBLIC_PATHS = ["/login", "/auth/callback", "/auth/signout"];

export async function middleware(request: NextRequest) {
  const { supabase, response } = createMakxasMiddlewareClient(request);

  // IMPORTANT: do NOT remove getUser(). It refreshes the session cookie.
  const { data: { user } } = await supabase.auth.getUser();

  const { pathname } = request.nextUrl;
  const isPublic = PUBLIC_PATHS.some((p) => pathname === p || pathname.startsWith(p + "/"));

  if (!user && !isPublic) {
    const url = request.nextUrl.clone();
    url.pathname = "/login";
    url.searchParams.set("next", pathname);
    return NextResponse.redirect(url);
  }

  return response;
}
```

## Why a peer-dependency design

Each consuming repo manages its own `next` / `@supabase/ssr` / `@supabase/supabase-js`
versions to avoid lock-step upgrades. Listed as `peerDependencies` so install will
warn (not fail) on version mismatch. Tested against:

- `next` 14, 15, 16
- `@supabase/ssr` 0.5 〜 0.10

## Status

- 0.1.0 — initial release. Migration target: 6 makxas repos.
