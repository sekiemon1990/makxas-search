# makxas-ai-kit（マクサスAIキット）

全業務ツール共通の「埋め込み型AIアシスタント（マクサスコパイロット）」の**共有 SoT**。
UI は別（`ai-widget` 参照実装）、LLM の**実行は各ツールの自サーバ**で行う。この repo が持つのは
「契約・統制・営業思想・モデル単価・トリアージ規約」だけ（＝中央に集めるのは実行ではなく契約と要約）。

- 設計全体: `makxas-ai-native/proposals/inbox/2026-06-20-ai-assistant-widget-platform.md`（v0.2）
- サービス境界の決定: `makxas-ai-native/decisions/ADR-0029-copilot-assistant-platform-boundary.md`

## 構造

| パス | 役割 |
|---|---|
| `src/contracts/context-envelope.ts` | コンテキスト・エンベロープ（いまどの画面・対象・権限・できること）。全形態必須。 |
| `src/contracts/conversation.ts` | AIイベント契約（会話・メッセージ・usage）。物理スキーマは統一せず論理契約で揃える。 |
| `src/contracts/pending-action.ts` | 承認フロー型（書込は pending→承認→実行・fail-closed）。recording の方式を全社標準化。 |
| `src/doctrine/sales-doctrine.ts` | 営業思想 core（レバー2フレームワーク）。各ツールは「core + 固有」を合成。実行promptの正本。 |
| `src/models/registry.ts` | モデル選択・単価・円換算の単一責務。コスト計算の散在を解消。 |
| `src/triage/triage-policy.ts` | 現場フィードバック→開発のトリアージ規約（軽微=AI自律 / 大=人間判断）。 |

## 原則（ADR-0029 / 全社標準）

- 実行は各ツール。中央に集めるのは契約と要約のみ。
- scope はサーバ側解決・fail-closed（ADR-0012）。LLM 呼び出しは連携台帳へ登録（ADR-0028）。
- 記憶層は正本を中央集約しない（docs/09）。
- 配布は `@makxas/supabase-next` 等と同じ vendor tgz 方式に倣う（いきなり public npm にしない）。

## 状態

Phase 0（土台）。型・規約・営業思想 core の骨格を定義中。実行アダプタは各ツール側。
